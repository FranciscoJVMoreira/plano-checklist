import { useState } from "react";

const dias = [
  "Segunda-feira",
  "Terça-feira",
  "Quarta-feira",
  "Quinta-feira",
  "Sexta-feira",
  "Sábado",
  "Domingo",
];

const plano = {
  "Segunda-feira": {
    treino: [
      "Ponte glútea no chão – 3x15",
      "Leg press com encosto – 3x12",
      "Abdução de quadril – 3x15",
      "Panturrilha sentado – 3x20",
      "Bird-dog – 3x10 por lado",
      "Caminhada leve – 20 min",
    ],
    refeicoes: [
      "Café: Omelete + pão integral",
      "Lanche: Maçã",
      "Almoço: Frango + arroz + legumes",
      "Lanche tarde: Iogurte natural",
      "Jantar: Sopa de legumes",
    ],
  },
  "Terça-feira": {
    treino: ["Cardio leve ou descanso ativo – 30 a 40 min"],
    refeicoes: [
      "Café: Omelete + pão integral",
      "Refeições similares à segunda",
    ],
  },
  "Quarta-feira": {
    treino: [
      "Remada baixa com encosto – 3x12",
      "Puxada frontal – 3x12",
      "Desenvolvimento de ombros sentado – 3x12",
      "Rosca direta leve – 3x12",
      "Tríceps polia – 3x12",
      "Prancha com joelhos – 3x30s",
    ],
    refeicoes: [
      "Café: Omelete + pão integral",
      "Lanche: Banana",
      "Almoço: Frango + arroz + legumes",
      "Jantar: Salada com atum",
    ],
  },
  "Quinta-feira": {
    treino: ["Cardio leve ou descanso ativo – 30 a 40 min"],
    refeicoes: ["Café: Omelete + pão integral", "Refeições similares à quarta"],
  },
  "Sexta-feira": {
    treino: [
      "Alongamento posterior – 3x20s",
      "Dead bug – 3x10 por lado",
      "Mini agachamento – 3x15",
      "Step-up – 3x10 por perna",
      "Caminhada ou bike – 30 min",
    ],
    refeicoes: [
      "Café: Omelete + pão integral",
      "Almoço: Frango ou carne + arroz + legumes",
      "Jantar: Sopa detox",
    ],
  },
  "Sábado": {
    treino: ["Descanso ativo ou caminhada leve"],
    refeicoes: [
      "Café: Panqueca de banana",
      "Almoço: Peixe assado + purê + legumes",
      "Jantar: Omelete de legumes",
    ],
  },
  "Domingo": {
    treino: ["Descanso ou caminhada leve"],
    refeicoes: [
      "Café: Tapioca + queijo",
      "Almoço: Refeição livre moderada",
      "Jantar: Salada com ovo ou frango",
    ],
  },
};

export default function PlanoCheckList() {
  const [checklist, setChecklist] = useState({});

  const toggleCheck = (dia, tipo, index) => {
    const key = `${dia}-${tipo}-${index}`;
    setChecklist((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4 text-center">
        Plano Diário - Treino e Dieta (Hérnia L2)
      </h1>
      {dias.map((dia) => (
        <div key={dia} className="mb-6 p-4 border rounded-2xl shadow">
          <h2 className="text-xl font-semibold mb-2">{dia}</h2>

          <h3 className="font-semibold">Treino:</h3>
          <ul className="mb-2">
            {plano[dia].treino.map((item, i) => {
              const key = `${dia}-treino-${i}`;
              return (
                <li key={key} className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={!!checklist[key]}
                    onChange={() => toggleCheck(dia, "treino", i)}
                  />
                  {item}
                </li>
              );
            })}
          </ul>

          <h3 className="font-semibold">Alimentação:</h3>
          <ul>
            {plano[dia].refeicoes.map((item, i) => {
              const key = `${dia}-refeicoes-${i}`;
              return (
                <li key={key} className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={!!checklist[key]}
                    onChange={() => toggleCheck(dia, "refeicoes", i)}
                  />
                  {item}
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </div>
  );
}