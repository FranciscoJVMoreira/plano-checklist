import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import PlanoCheckList from './PlanoCheckList';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <PlanoCheckList />
  </React.StrictMode>
);